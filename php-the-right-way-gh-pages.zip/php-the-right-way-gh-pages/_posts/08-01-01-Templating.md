---
title: Templating
anchor: templating
---

# Plantillas {#templating_title}

Las plantillas proporcionan una manera conveniente de separar el controlador y la lógica de dominio de su lógica de presentación.
Las plantillas normalmente contienen el HTML de tu aplicación, pero pueden ser usadas también para otros formatos, como XML.
A las plantillas también se les llaman 'vistas', que constituyen parte del segundo componente del patrón de arquitectura de software [modelo-vista-controlador](./pages/Design-Patterns.html#model-view-controller) (MVC).
