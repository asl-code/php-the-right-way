---
title: Recursos
anchor: recursos
---

# Recursos

## Directamente de la fuente

* [Sitio web de PHP](http://php.net/)
* [Documentación de PHP](http://www.php.net/manual/es/)

## Gente a seguir

* [Rasmus Lerdorf](http://twitter.com/rasmus)
* [Fabien Potencier](http://twitter.com/fabpot)
* [Derick Rethans](http://twitter.com/derickr)
* [Chris Shiflett](http://twitter.com/shiflett)
* [Sebastian Bergmann](http://twitter.com/s_bergmann)
* [Matthew Weier O'Phinney](http://twitter.com/weierophinney)
* [Nikita Popov](http://twitter.com/nikita_ppv)

## Mentores

* [phpmentoring.org](http://phpmentoring.org/) - Asesoramiento formal y directo para la comunidad de PHP.

## Proveedores de PHP PaaS

* [PagodaBox](https://pagodabox.com/)
* [PHP Fog](https://phpfog.com/)
* [Engine Yard Orchestra PHP Platform](http://www.engineyard.com/products/orchestra/)
* [Red Hat OpenShift Platform](http://www.redhat.com/products/cloud-computing/openshift/)
* [dotCloud](http://docs.dotcloud.com/services/php/)
* [AWS Elastic Beanstalk](http://aws.amazon.com/elasticbeanstalk/)
* [cloudControl](https://www.cloudcontrol.com/)
* [Windows Azure](http://www.windowsazure.com/)
