---
title: Plataforma como Servicio (PaaS)
anchor: paas
isChild: true
---

## Plataforma como Servicio (PaaS) {#paas}

Las aplicaciones PHP se pueden desplegar y ejecutar en servidores web de producción de varias maneras.

PaaS provee la arquitectura adecuada del sistema y la red que se necesitan para ejecutar aplicaciones PHP en la web. Esto significa que no es necesaria una configuración extensa del servidor para lanzar aplicaciones o armazones de PHP.

Recientemente, PaaS se ha convertido en un método muy popular de desplegar, alojar, y ampliar aplicaciones PHP de todos los tamaños. Encontrará una lista de **Proveedores de PHP PaaS** en la [sección de recursos](#recursos).
