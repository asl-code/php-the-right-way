---
title: Servidores y Despliegue
anchor: servidores-y-despliegue
---

# Servidores y Despliegue

Las aplicaciones PHP se pueden desplegar y ejecutar en servidores web de producción de varias maneras.
