---
title: Errors and Exceptions
anchor: errores-y-excepciones
---

# Errors and Exceptions {#errores-y-excepciones}

