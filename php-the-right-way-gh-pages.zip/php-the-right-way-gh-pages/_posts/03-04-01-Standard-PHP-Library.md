---
title: Librería Estándar de PHP
anchor: libreria-estandar-de-php
isChild: true
---

## Librería Estándar de PHP {#libreria-estandar-de-php}

La Librería Estándar de PHP (SPL) viene empaquetada con PHP y provee una colección de clases e interfaces compuesta principalmente de clases de estructura de datos (como stack, queue y heap) e iteradores que pueden atravesar estas estructuras de datos o sus propias clases que implementan las interfaces de la SPL.

* [Leer acerca de la SPL][spl]

[spl]: http://php.net/manual/es/book.spl.php
